﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Teste_CRMALL.Entidades;
using Teste_CRMALL.RegrasDeNegocio;

namespace Teste_CRMALL
{
    public partial class Clientes : Form
    {
        public List<ClienteDto> ListaClientes;
        public ClienteDto cli = null;

        public Clientes()
        {
            InitializeComponent();
        }

        public void RecarregarInformacoesNaTabela()
        {
            Banco banco = new Banco();
            ListaClientes = banco.RecuperarClientesBanco();
            if (ListaClientes.Count > 0)
                cli = ListaClientes[0];

            dgClientes.DataSource = ListaClientes;
        }
        private void Clientes_Load(object sender, EventArgs e)
        {
            ListaClientes = new List<ClienteDto>();

            RecarregarInformacoesNaTabela();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            RegrasClientes regras = new RegrasClientes();

            regras.AdicionarCliente(this);

            if (!ListaClientes.Contains(cli))
            {
                ListaClientes.Add(cli);
                RecarregarInformacoesNaTabela();
            }
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            if(cli != null)
            {
                ListaClientes.Remove(cli);

                dgClientes.DataSource = null;
                dgClientes.DataSource = ListaClientes;

                if (ListaClientes.Count > 0)
                    cli = ListaClientes[0];
                else
                    cli = null;
            }
        }

        private void dgClientes_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            cli = ListaClientes[e.RowIndex];

            RegrasClientes regras = new RegrasClientes();
            regras.EditarCliente(cli, this);
        }

        private void txFiltrar_TextChanged(object sender, EventArgs e)
        {
            if (txFiltrar.Text.Equals(""))
            {
                dgClientes.DataSource = null;
                dgClientes.DataSource = ListaClientes;
            }
            else
            {
                List<ClienteDto> aux = new List<ClienteDto>();
                foreach (ClienteDto cli in ListaClientes)
                {
                    if (cli.Nome.ToLower().Contains(txFiltrar.Text.ToLower()))
                        aux.Add(cli);
                }

                dgClientes.DataSource = null;
                dgClientes.DataSource = aux;
            }
        }

        private void dgClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cli = ListaClientes[e.RowIndex];
        }
    }
}
