﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Teste_CRMALL.Entidades;
using Teste_CRMALL.RegrasDeNegocio;

namespace Teste_CRMALL
{
    public partial class Acoes : Form
    {
        public ClienteDto cli;
        public Clientes tela;
        public Comuns comuns;
        public Acoes()
        {
            InitializeComponent();
        }

        private void Acoes_Load(object sender, EventArgs e)
        {
            comuns = new Comuns();
            lbNome.ForeColor = Color.Red;

            if (cli != null)
            {
                lbNome.ForeColor = Color.Black;
                txNome.Text = cli.Nome;
                dtNascimento.Value = cli.Nascimento;
                if(cli.Sexo.Equals("M"))
                {
                    rbMasculino.Checked = true;
                    rbFeminino.Checked = false;
                }
                else
                {
                    rbMasculino.Checked = false;
                    rbFeminino.Checked = true;
                }
                txCEP.Text = cli.Endereco.Cep;
                txEndereco.Text = cli.Endereco.Endereco;
                txNumero.Text = cli.Endereco.Numero != null ? cli.Endereco.Numero.ToString() : "";
                txComplemento.Text = cli.Endereco.Complemento;
                txBairro.Text = cli.Endereco.Bairro;
                txCidade.Text = cli.Endereco.Cidade;
                txEstado.Text = cli.Endereco.Estado;
            }
        }

        private bool VerificarCamposObrigatorios()
        {
            return !txNome.Text.Equals("") && dtNascimento.Value != null;
        }

        private bool ValidarCampos()
        {
            return !comuns.VerificarSeExisteLetra(txNumero.Text);
        }

        private void BloquearCampos()
        {
            txEndereco.Enabled = false;
            txBairro.Enabled = false;
            txEstado.Enabled = false;
            txCidade.Enabled = false;
        }

        private void LiberarCampos()
        {
            txEndereco.Enabled = true;
            txBairro.Enabled = true;
            txEstado.Enabled = true;
            txCidade.Enabled = true;
        }

        private ClienteDto CriarCliente()
        {
            return new ClienteDto
            {
                Nome = txNome.Text,
                Nascimento = dtNascimento.Value,
                Sexo = rbMasculino.Checked == true ? "M" : "S",
                Endereco = new EnderecoDto
                {
                    Cep = txCEP.Text,
                    Endereco = txEndereco.Text,
                    Numero = txNumero.Text.Equals("") ? 0 : Int32.Parse(txNumero.Text),
                    Complemento = txComplemento.Text,
                    Bairro = txBairro.Text,
                    Cidade = txCidade.Text,
                    Estado = txEstado.Text
                }
            };
        }
        private void AtualizarCliente()
        {
            cli.Nome = txNome.Text;
            cli.Nascimento = dtNascimento.Value;
            cli.Sexo = rbMasculino.Checked == true ? "M" : "S";
            cli.Endereco.Cep = txCEP.Text;
            cli.Endereco.Endereco = txEndereco.Text;
            cli.Endereco.Numero = txNumero.Text.Equals("") ? 0 : Int32.Parse(txNumero.Text);
            cli.Endereco.Complemento = txComplemento.Text;
            cli.Endereco.Bairro = txBairro.Text;
            cli.Endereco.Cidade = txCidade.Text;
            cli.Endereco.Estado = txEstado.Text;
        }
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if(VerificarCamposObrigatorios() && ValidarCampos())
            {
                if (cli == null)
                    cli = CriarCliente();
                else
                    AtualizarCliente();

                tela.cli = cli;
                Close();
            }
            else
            {
                MessageBox.Show("Algum erro encontrado ao salvar, favor verificar campos com nome em vermelho.");
            }
            
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnBuscarCEP_Click(object sender, EventArgs e)
        {
            
            EnderecoDto endereco;
            var cep = txCEP.Text.Replace('-', ' ').Trim();
            if (comuns.VerificaFormatoCEP(cep))
            {
                WebService webService = new WebService();
                endereco = webService.RetornarEndereco(cep);
                if (endereco != null)
                {
                    CarregarCamposEndereco(endereco);
                    BloquearCampos();
                }
            }
        }

        private void CarregarCamposEndereco(EnderecoDto endereco)
        {
            txEndereco.Text = endereco.Endereco;
            txBairro.Text = endereco.Bairro;
            txEstado.Text = endereco.Estado;
            txComplemento.Text = endereco.Complemento;
            txCidade.Text = endereco.Cidade;
        }

        private void rbMasculino_CheckedChanged(object sender, EventArgs e)
        {
            rbFeminino.Checked = !rbMasculino.Checked;
        }

        private void rbFeminino_CheckedChanged(object sender, EventArgs e)
        {
            rbMasculino.Checked = !rbFeminino.Checked;
        }

        private void txCEP_TextChanged(object sender, EventArgs e)
        {
            LiberarCampos();
        }

        private void txNumero_TextChanged(object sender, EventArgs e)
        {
            if (comuns.VerificarSeExisteLetra(txNumero.Text))
                lbNumero.ForeColor = Color.Red;
            else
            {
                lbNumero.ForeColor = Color.Black;
            }

        }

        private void txNome_TextChanged(object sender, EventArgs e)
        {
            if (txNome.Text.Equals(""))
                lbNome.ForeColor = Color.Red;
            else
            {
                lbNome.ForeColor = Color.Black;
            }
        }
    }
}
