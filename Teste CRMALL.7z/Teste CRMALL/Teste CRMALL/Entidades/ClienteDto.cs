﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Teste_CRMALL.Entidades
{
    public class ClienteDto
    {
        public int? Handle { get; set; }
        public String Nome { get; set; }
        public DateTime Nascimento { get; set;}
        public string Sexo { get; set; }
        public EnderecoDto Endereco { get; set; }
    }
}
