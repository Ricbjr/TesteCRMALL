﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Teste_CRMALL.Entidades
{
    public class EnderecoDto
    {
        public String Cep { get; set; }
        public String Endereco { get; set; }
        public int? Numero { get; set; }
        public String Complemento { get; set; }
        public String Bairro { get; set; }
        public String Cidade { get; set; }
        public String Estado { get; set; }

    }
}
