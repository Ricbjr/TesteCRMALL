﻿using System;
using System.Collections.Generic;
using System.Text;
using Teste_CRMALL.Entidades;
using System.Net;
using System.IO;
using System.Text.Json;

namespace Teste_CRMALL.RegrasDeNegocio
{
    public class WebService
    {
        public EnderecoDto RetornarEndereco(String cep)
        {
            var response = RequisicaoGET(cep);

            if(VerificaExisteCEP(response))
                return CarregarInformacoesCep(response);

            return null;
        }

        private bool VerificaExisteCEP(String response)
        {
            return !response.Contains("\"erro\"");
        }

        private string RequisicaoGET(String cep)
        {
            var requisicaoWeb = WebRequest.CreateHttp("https://viacep.com.br/ws/"+cep+"/json/");
            requisicaoWeb.Method = "GET";
            requisicaoWeb.UserAgent = "Requisicao";

            using (var resposta = requisicaoWeb.GetResponse())
            {
                var streamDados = resposta.GetResponseStream();
                StreamReader reader = new StreamReader(streamDados);
                var objResponse = reader.ReadToEnd();

                streamDados.Close();
                resposta.Close();

                return objResponse;
            }
        }

        private EnderecoDto CarregarInformacoesCep(string response)
        {
            ObjJSONDto objJSON = JsonSerializer.Deserialize<ObjJSONDto>(response);

            return new EnderecoDto
            {
                Cep = objJSON.cep,
                Endereco = objJSON.logradouro,
                Complemento = objJSON.complemento,
                Bairro = objJSON.bairro,
                Cidade = objJSON.localidade,
                Estado = objJSON.uf
            };
        }
    }
}
