﻿using System;
using System.Collections.Generic;
using Teste_CRMALL.Entidades;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace Teste_CRMALL.RegrasDeNegocio
{
    public class Banco
    {
        private MySqlConnection conexao;

        #region Constantes
        private const int posHandle = 0;
        private const int posNome = 1;
        private const int posDataNascimento = 2;
        private const int posSexo = 3;
        private const int posCep = 4;
        private const int posEndereco = 5;
        private const int posNumero = 6;
        private const int posComplemento = 7;
        private const int posBairro = 8;
        private const int posCidade = 9;
        private const int posEstado = 10;

        #endregion

        private bool Conectar()
        {
            var SqlConnection = "Server=localhost;Database=teste;User=root;password=senha;port=3300";
            conexao= new MySqlConnection(SqlConnection);

            try
            {
                conexao.Open();
                return true;
            }
            catch(Exception e)
            {
                return false;
            }
            
        }

        private void Desconectar()
        {
            if (VerificarConexaoAberta())
                conexao.Close();
        }

        private bool VerificarConexaoAberta()
        {
            return conexao.State == ConnectionState.Open;
        }
        public List<ClienteDto> RecuperarClientesBanco()
        {
            var ListaClientes = new List<ClienteDto>();

            try
            {
                Conectar();
                VerificarConexaoAberta();
                var comando = conexao.CreateCommand();
                comando.CommandText = "SELECT * FROM CLIENTES";
                var dataReader = comando.ExecuteReader();

                while(dataReader.Read())
                {
                    ListaClientes.Add(new ClienteDto
                    {
                        Handle = Int32.Parse(dataReader[posHandle].ToString()),
                        Nome = dataReader[posNome].ToString(),
                        Nascimento = DateTime.Parse(dataReader[posDataNascimento].ToString()),
                        Sexo = dataReader[posSexo].ToString(),
                        Endereco = new EnderecoDto
                        {
                            Cep = dataReader[posCep].ToString(),
                            Endereco = dataReader[posEndereco].ToString(),
                            Numero = Int32.Parse(dataReader[posNumero].ToString()),
                            Complemento = dataReader[posComplemento].ToString(),
                            Bairro = dataReader[posBairro].ToString(),
                            Cidade = dataReader[posCidade].ToString(),
                            Estado = dataReader[posEstado].ToString()
                        }
                    });
                }
            }
            catch(Exception e)
            {
                MessageBox.Show("Ocorreu o seguinte erro ao recuperar os dados do banco: " + e);
                return new List<ClienteDto>();
            }
            finally
            {
                Desconectar();
            }
            
            return ListaClientes;
        }

        public bool AdicionarClienteBanco(ClienteDto cli)
        {
            Conectar();
            
            try
            {
                VerificarConexaoAberta();
                var comando = conexao.CreateCommand();
                comando.CommandText = "INSERT INTO CLIENTES " +
                                      "(NOME, DATANASCIMENTO, SEXO, CEP, ENDERECO, NUMERO, COMPLEMENTO, BAIRRO, ESTADO, CIDADE) VALUES" +
                                      "(" + cli.Nome + "," + cli.Nascimento + "," + cli.Sexo + "," + cli.Endereco.Cep + "," + cli.Endereco.Endereco +
                                      "," + cli.Endereco.Numero + "," + cli.Endereco.Complemento + "," + cli.Endereco.Bairro + "," + cli.Endereco.Estado +
                                      "," + cli.Endereco.Cidade + ")";
                comando.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show("Ocorreu o seguinte erro ao adicionar um cliente no banco: " + e);
                return false;
            }
            finally
            {
                Desconectar();
            }
            
            return true;
        }

        public bool EditarClienteBanco(ClienteDto cli)
        {
            Conectar();
            try
            {
                VerificarConexaoAberta();
                var comando = conexao.CreateCommand();
                comando.CommandText = "UPDATE CLIENTES " +
                                      "   SET NOME = " + cli.Nome + "," +
                                      "       DATANASCIMENTO = " + cli.Nascimento + "," +
                                      "       SEXO = " + cli.Sexo + "," +
                                      "       CEP = " + cli.Endereco.Cep + "," +
                                      "       ENDERECO = " + cli.Endereco.Endereco + "," +
                                      "       NUMERO = " + cli.Endereco.Numero + "," +
                                      "       COMPLEMENTO = " + cli.Endereco.Complemento + "," +
                                      "       BAIRRO = " + cli.Endereco.Bairro + "," +
                                      "       ESTADO = " + cli.Endereco.Estado + "," +
                                      "       CIDADE = " + cli.Endereco.Cidade +
                                      " WHERE HANDLE = " + cli.Handle;
                comando.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show("Ocorreu o seguinte erro ao editar um cliente do banco: " + e);
                return false;
            }
            finally
            {
                Desconectar();
            }
            
            return true;
        }

        public bool RemoverClienteBanco(ClienteDto cli)
        {
            Conectar();
            try
            {
                VerificarConexaoAberta();
                var comando = conexao.CreateCommand();
                comando.CommandText = "DELETE FROM CLIENTES " +
                                      " WHERE HANDLE = " + cli.Handle;
                comando.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show("Ocorreu o seguinte erro ao remover um cliente do banco: " + e);
                return false;
            }
            finally
            {
                Desconectar();
            }
            
            return true;
        }
    }
}
