﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Teste_CRMALL.RegrasDeNegocio
{
    public class Comuns
    {
        private const int tamanhoValidoCep = 8;

        public bool VerificaFormatoCEP(String cep)
        {
            return !VerificarSeExisteLetra(cep) && cep.Length == tamanhoValidoCep;
        }

        public bool VerificarSeExisteLetra(String s)
        {
            if (s.Where(letra => char.IsLetter(letra)).Count() > 0)
                return true;
            else
                return false;
        }

        
    }
}
