﻿using System;
using System.Collections.Generic;
using System.Text;
using Teste_CRMALL.Entidades;

namespace Teste_CRMALL.RegrasDeNegocio
{
    public class RegrasClientes
    {
        public void AdicionarCliente(Clientes tela)
        {
            ClienteDto auxiliar = tela.cli;

            Acoes add = new Acoes();
            add.Text = "Adicionar novo Cliente";
            add.tela = tela;
            add.ShowDialog();

            if(tela.cli != auxiliar)
            {
                Banco banco = new Banco();
                banco.AdicionarClienteBanco(tela.cli);
            }
        }

        public void EditarCliente(ClienteDto cli, Clientes tela)
        {
            Acoes edicao = new Acoes();
            edicao.Text = "Edição do cliente " + cli.Nome;
            edicao.cli = cli;
            edicao.tela = tela;

            edicao.ShowDialog();

            Banco banco = new Banco();
            banco.EditarClienteBanco(cli);
        }

        public void RemoverCliente(ClienteDto cli)
        {
            Banco banco = new Banco();
            banco.RemoverClienteBanco(cli);
        }
    }
}
